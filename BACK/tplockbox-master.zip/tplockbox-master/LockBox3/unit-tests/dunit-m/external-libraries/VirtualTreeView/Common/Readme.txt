This folder contains files which are used by Virtual Treeview but are of general interest, not only for Virtual Treeview.

Mike, June 2009