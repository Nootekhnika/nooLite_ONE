64 bit version of LockBox2 for Delphi 2009, XE, XE2, XE3, FPC and Lazarus.

Please read readme-64.txt for the most recent changes.

readme-64.txt        64 bit changes by Jarto Tarpio, Sebastian Zierer and Arthur Pijpers
readme-tiburon.txt   Delphi 2009-, XE-, XE2- and XE3-changes by Sebastian Zierer
readme-orig.txt      The original readme.txt
